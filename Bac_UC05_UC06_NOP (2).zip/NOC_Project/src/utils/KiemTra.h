// Khung ho tro de chay phan Bac; can thong nhat voi nhom khi tich hop.
// Nguoi hoan thien: [DIEN HO TEN] - MSSV: [DIEN MSSV]
#pragma once
#include <iostream>
#include <string>
#include <sstream>
#include <stdexcept>
using namespace std;

// Ngoai le rieng giup phan biet loi nhap voi loi luu file.
class LoiLuuFile : public runtime_error {
public:
    LoiLuuFile(string s) : runtime_error(s) {}
};
class LoiThamChieu : public runtime_error {
public:
    LoiThamChieu(string s) : runtime_error(s) {}
};
class HetDuLieu : public runtime_error {
public:
    HetDuLieu() : runtime_error("Da dung nhap.") {}
};
inline string nhapDong(string thongBao) {
    cout << thongBao;
    string s;
    if (!getline(cin, s)) throw HetDuLieu();
    return s;
}
inline bool maHopLe(string s) {
    if (s.empty() || s.length() > 20) return false;
    for (int i = 0; i < (int)s.length(); i++) {
        char c = s[i];
        if (!((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
              (c >= '0' && c <= '9') || c == '_' || c == '-')) return false;
    }
    return true;
}
inline bool noiDungHopLe(string s, int toiDa) {
    if (s.empty() || (int)s.length() > toiDa) return false;
    bool coChu = false;
    for (int i = 0; i < (int)s.length(); i++) {
        if (s[i] == '|' || (unsigned char)s[i] < 32) return false;
        if (s[i] != ' ') coChu = true;
    }
    return coChu;
}
inline bool ngayHopLe(string s) {
    if (s.length() != 10 || s[2] != '/' || s[5] != '/') return false;
    for (int i = 0; i < 10; i++) {
        if (i != 2 && i != 5 && (s[i] < '0' || s[i] > '9')) return false;
    }
    int ngay = (s[0] - '0') * 10 + s[1] - '0';
    int thang = (s[3] - '0') * 10 + s[4] - '0';
    int nam = (s[6] - '0') * 1000 + (s[7] - '0') * 100
            + (s[8] - '0') * 10 + s[9] - '0';
    if (nam < 1900 || nam > 2100 || thang < 1 || thang > 12) return false;
    int soNgay[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    if (nam % 400 == 0 || (nam % 4 == 0 && nam % 100 != 0)) soNgay[1] = 29;
    return ngay >= 1 && ngay <= soNgay[thang - 1];
}
// Tach dung so truong trong mot dong file, vi du N001|Router Ha Noi|Router|Active.
inline void tachDong(string dong, string truong[], int soTruong) {
    int dem = 0;
    for (int i = 0; i < (int)dong.length(); i++) {
        if (dong[i] == '|') dem++;
    }
    if (dem != soTruong - 1) throw invalid_argument("Sai so truong du lieu.");
    stringstream ss(dong);
    for (int i = 0; i < soTruong; i++) getline(ss, truong[i], '|');
}
