// Phan viec: Bac - Ho ten: [DIEN HO TEN] - MSSV: [DIEN MSSV]
#pragma once
#include "../entities/NetworkNode.h"
#include "../entities/Alarm.h"
#include "../repository/Repository.h"

// Dau &: thao tac tren danh sach chung, khong tao ban sao rieng.
void xoaNode(Repository<NetworkNode>& dsNode, const Repository<Alarm>& dsCanhBao);
void themCanhBao(const Repository<NetworkNode>& dsNode, Repository<Alarm>& dsCanhBao);
