// Phan viec: Bac - Ho ten: [DIEN HO TEN] - MSSV: [DIEN MSSV]
#include "Bac.h"

// UC05: XOA NODE. Day la ham thu nhat Bac can nam ro.
void xoaNode(Repository<NetworkNode>& dsNode, const Repository<Alarm>& dsCanhBao) {
    string ma = nhapDong("Nhap ma node can xoa: ");
    int viTri = dsNode.findIndex(ma);
    if (viTri == -1) {
        cout << "Khong tim thay node.\n";
        return;
    }

    // Khong xoa node neu bat ky canh bao nao con tro toi no.
    // Quy tac ap dung ca voi canh bao da xu ly.
    for (int i = 0; i < dsCanhBao.size(); i++) {
        if (dsCanhBao.at(i).getNodeId() == ma) {
            throw LoiThamChieu("Khong the xoa: node con canh bao tham chieu.");
        }
    }

    dsNode.at(viTri).display();
    string xacNhan = nhapDong("Ban muon xoa node nay? (y/n): ");
    if (xacNhan != "y" && xacNhan != "Y") {
        cout << "Da huy xoa.\n";
        return;
    }
    dsNode.remove(ma); // Ham nay don mang, giam n va luu file.
    cout << "Xoa node thanh cong.\n";
}

// UC06: THEM CANH BAO. Day la ham thu hai Bac can nam ro.
void themCanhBao(const Repository<NetworkNode>& dsNode, Repository<Alarm>& dsCanhBao) {
    if (dsCanhBao.full()) {
        cout << "Danh sach canh bao da day.\n";
        return;
    }
    Alarm moi;
    moi.inputData(); // Nhap va kiem tra dinh dang; trang thai moi la chua xu ly.

    if (dsCanhBao.exists(moi.getId())) {
        cout << "Ma canh bao da ton tai.\n";
        return;
    }
    if (!dsNode.exists(moi.getNodeId())) {
        throw LoiThamChieu("Node khong ton tai.");
    }
    dsCanhBao.add(moi); // Gan vao ds[n], tang n va luu file.
    cout << "Them canh bao thanh cong.\n";
}
