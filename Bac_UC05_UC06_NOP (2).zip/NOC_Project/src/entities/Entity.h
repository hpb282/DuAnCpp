// Khung ho tro de chay phan Bac; can thong nhat voi nhom khi tich hop.
// Nguoi hoan thien: [DIEN HO TEN] - MSSV: [DIEN MSSV]
#pragma once
#include <string>
using namespace std;

// Lop cha: quy dinh cac ham chung ma Node va Alarm phai co.
class Entity {
protected:
    string id;
public:
    virtual ~Entity() {}
    string getId() const { return id; }
    virtual void inputData() = 0;
    virtual void display() const = 0;
    virtual string toFileLine() const = 0;
    virtual void fromFileLine(string dong) = 0;
};
