// Khung ho tro de chay phan Bac; can thong nhat voi nhom khi tich hop.
// Nguoi hoan thien: [DIEN HO TEN] - MSSV: [DIEN MSSV]
#pragma once
#include "Entity.h"
#include "../utils/KiemTra.h"

class NetworkNode : public Entity {
private:
    string ten, loai, trangThai;
    void kiemTra() const {
        if (!maHopLe(id)) throw invalid_argument("Ma node khong hop le.");
        if (!noiDungHopLe(ten, 80)) throw invalid_argument("Ten node khong hop le.");
        if (loai != "Router" && loai != "Switch" && loai != "BTS" && loai != "Server")
            throw invalid_argument("Loai node khong hop le.");
        if (trangThai != "Active" && trangThai != "Down" && trangThai != "Maintenance")
            throw invalid_argument("Trang thai node khong hop le.");
    }
public:
    void inputData() override {
        id = nhapDong("Ma node: ");
        ten = nhapDong("Ten node: ");
        loai = nhapDong("Loai (Router/Switch/BTS/Server): ");
        trangThai = nhapDong("Trang thai (Active/Down/Maintenance): ");
        kiemTra();
    }
    void display() const override {
        cout << id << " | " << ten << " | " << loai << " | " << trangThai << '\n';
    }
    string toFileLine() const override {
        return id + "|" + ten + "|" + loai + "|" + trangThai;
    }
    void fromFileLine(string dong) override {
        string a[4];
        tachDong(dong, a, 4);
        id = a[0]; ten = a[1]; loai = a[2]; trangThai = a[3];
        kiemTra();
    }
};
