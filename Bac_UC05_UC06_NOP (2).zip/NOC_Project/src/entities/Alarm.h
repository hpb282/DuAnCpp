// Khung ho tro de chay phan Bac; can thong nhat voi nhom khi tich hop.
// Nguoi hoan thien: [DIEN HO TEN] - MSSV: [DIEN MSSV]
#pragma once
#include "Entity.h"
#include "../utils/KiemTra.h"

class Alarm : public Entity {
private:
    string maNode, mucDo, moTa, ngay, daXuLy;
    void kiemTra() const {
        if (!maHopLe(id)) throw invalid_argument("Ma canh bao khong hop le.");
        if (!maHopLe(maNode)) throw invalid_argument("Ma node khong hop le.");
        if (mucDo != "Critical" && mucDo != "Major" && mucDo != "Minor" && mucDo != "Warning")
            throw invalid_argument("Muc do khong hop le.");
        if (!noiDungHopLe(moTa, 200)) throw invalid_argument("Mo ta khong hop le.");
        if (!ngayHopLe(ngay)) throw invalid_argument("Ngay khong hop le.");
        if (daXuLy != "0" && daXuLy != "1") throw invalid_argument("Trang thai canh bao sai.");
    }
public:
    string getNodeId() const { return maNode; }
    void inputData() override {
        id = nhapDong("Ma canh bao: ");
        maNode = nhapDong("Ma node: ");
        mucDo = nhapDong("Muc do (Critical/Major/Minor/Warning): ");
        moTa = nhapDong("Mo ta: ");
        ngay = nhapDong("Ngay (dd/mm/yyyy): ");
        daXuLy = "0"; // Canh bao vua them luon chua xu ly.
        kiemTra();
    }
    void display() const override {
        cout << id << " | " << maNode << " | " << mucDo << " | " << moTa
             << " | " << ngay << " | Da xu ly: " << daXuLy << '\n';
    }
    string toFileLine() const override {
        return id + "|" + maNode + "|" + mucDo + "|" + moTa + "|" + ngay + "|" + daXuLy;
    }
    void fromFileLine(string dong) override {
        string a[6];
        tachDong(dong, a, 6);
        id = a[0]; maNode = a[1]; mucDo = a[2]; moTa = a[3]; ngay = a[4]; daXuLy = a[5];
        kiemTra();
    }
};
