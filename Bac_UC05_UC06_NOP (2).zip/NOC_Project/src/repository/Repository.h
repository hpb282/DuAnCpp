// Khung ho tro de chay phan Bac; can thong nhat voi nhom khi tich hop.
// Nguoi hoan thien: [DIEN HO TEN] - MSSV: [DIEN MSSV]
#pragma once
#include <fstream>
#include "../entities/Entity.h"
#include "../utils/KiemTra.h"

// T la kieu du lieu: NetworkNode hoac Alarm. Ben trong van la mang va bien dem.
// Dung cung mot lop cho hai danh sach, tranh viet lap ham tim, them, xoa, luu.
template <typename T>
class Repository {
private:
    T ds[100];
    int n;
    string tenFile;
public:
    Repository(string file) : n(0), tenFile(file) { load(); }
    int size() const { return n; }
    bool full() const { return n == 100; }
    const T& at(int i) const {
        if (i < 0 || i >= n) throw out_of_range("Chi so ngoai mang.");
        return ds[i];
    }
    int findIndex(string ma) const {
        for (int i = 0; i < n; i++) {
            if (ds[i].getId() == ma) return i;
        }
        return -1;
    }
    bool exists(string ma) const { return findIndex(ma) != -1; }
    void load() {
        ifstream tep(tenFile.c_str());
        if (!tep) throw runtime_error("Khong mo duoc " + tenFile);
        n = 0;
        string dong;
        while (getline(tep, dong)) {
            if (!dong.empty() && dong[dong.length() - 1] == '\r') dong.erase(dong.length() - 1);
            if (full()) throw runtime_error("Vuot 100 ban ghi: " + tenFile);
            T x;
            x.fromFileLine(dong);
            if (exists(x.getId())) throw runtime_error("Ma trung trong " + tenFile);
            ds[n] = x;
            n++;
        }
        if (!tep.eof()) throw runtime_error("Loi doc " + tenFile);
    }
    void save() const {
        // Ban co ban ghi truc tiep. Can sao luu data truoc khi demo.
        ofstream tep(tenFile.c_str());
        if (!tep) throw LoiLuuFile("Khong mo duoc de ghi: " + tenFile);
        for (int i = 0; i < n; i++) tep << ds[i].toFileLine() << '\n';
        tep.close();
        if (tep.fail()) throw LoiLuuFile("Ghi file that bai: " + tenFile);
    }
    void add(const T& x) {
        if (full()) throw invalid_argument("Danh sach da day.");
        if (exists(x.getId())) throw invalid_argument("Ma da ton tai.");
        ds[n] = x; // Them vao cuoi mang.
        n++;
        save();
    }
    void remove(string ma) {
        int viTri = findIndex(ma);
        if (viTri == -1) throw invalid_argument("Khong tim thay ma.");
        // Don trai, sau do giam so luong phan tu.
        for (int i = viTri; i < n - 1; i++) ds[i] = ds[i + 1];
        n--;
        save();
    }
};
